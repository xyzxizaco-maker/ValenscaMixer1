# Membuat APK Valensca Mixer hanya dengan HP Android

Folder ini adalah proyek Android native (Kotlin/Gradle), bukan APK siap instal.
Workflow GitHub Actions disertakan agar APK debug dapat dibangun di cloud tanpa komputer.

1. Ekstrak ZIP proyek ini di HP.
2. Buat repository baru di GitHub melalui browser dan unggah isi folder proyek (bukan folder ZIP-nya).
3. Buka tab **Actions** pada repository. Jika diminta, aktifkan Actions.
4. Pilih workflow **Build Valensca Mixer APK** lalu tekan **Run workflow**.
5. Tunggu sampai proses selesai dengan status hijau.
6. Buka hasil run dan unduh artifact **ValenscaMixer-debug-apk**.
7. Ekstrak artifact ZIP, lalu buka `app-debug.apk` untuk memasang. Izinkan pemasangan aplikasi dari sumber tersebut jika Android meminta.

Catatan:
- Build ini adalah APK debug untuk pengujian, bukan rilis Play Store.
- Aplikasi meminta izin mikrofon. Uji dengan headphone dan volume rendah untuk menghindari feedback.
- CH3–CH8 belum menerima input fisik; saat ini hanya slot input perangkat lunak.
- Output stereo Android tidak otomatis menjadi input audio YouTube Live.
