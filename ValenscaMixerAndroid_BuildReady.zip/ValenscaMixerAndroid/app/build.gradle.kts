plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.valensca.mixer"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.valensca.mixer"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    kotlinOptions { jvmTarget = "17" }
}
