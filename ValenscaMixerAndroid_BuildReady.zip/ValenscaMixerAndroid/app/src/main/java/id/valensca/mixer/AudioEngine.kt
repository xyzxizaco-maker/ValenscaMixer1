package id.valensca.mixer

import android.content.ContentResolver
import android.net.Uri
import android.media.*
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * 8-strip software mixer prototype.
 * CH1: phone microphone. CH2: mono/stereo PCM WAV file. CH3-CH8: virtual input buses
 * available through pushExternalInput(). Physical multi-channel USB input is not yet wired.
 * Output: stereo AudioTrack to the Android selected playback device.
 */
class AudioEngine {
    companion object { const val SAMPLE_RATE = 44100; const val CHANNELS = 8; private const val BLOCK = 256 }

    data class Params(
        @Volatile var gain: Float = 0.8f,
        @Volatile var fader: Float = 0.8f,
        @Volatile var pan: Float = 0f,
        @Volatile var muted: Boolean = false,
        @Volatile var aux1: Float = 0f,
        @Volatile var aux2: Float = 0f,
        val eq: FloatArray = FloatArray(4)
    )

    private val params = Array(CHANNELS) { Params() }
    private val external = Array(CHANNELS) { FloatArray(BLOCK) }
    private val externalLock = Any()
    @Volatile private var running = false
    @Volatile private var musicPlaying = false
    @Volatile private var music: FloatArray? = null
    @Volatile private var musicPosition = 0
    @Volatile var lastError: String = ""
        private set
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var worker: Thread? = null
    @Volatile var masterLevel: Float = 0.85f
    @Volatile var delayLevel: Float = 0.25f
    @Volatile var reverbLevel: Float = 0.25f

    fun setChannel(index: Int, gain: Float? = null, fader: Float? = null, pan: Float? = null,
                   muted: Boolean? = null, aux1: Float? = null, aux2: Float? = null,
                   eqBand: Int? = null, eqDb: Float? = null) {
        if (index !in 0 until CHANNELS) return
        val p = params[index]
        gain?.let { p.gain = it.coerceIn(0f, 2f) }
        fader?.let { p.fader = it.coerceIn(0f, 1f) }
        pan?.let { p.pan = it.coerceIn(-1f, 1f) }
        muted?.let { p.muted = it }
        aux1?.let { p.aux1 = it.coerceIn(0f, 1f) }
        aux2?.let { p.aux2 = it.coerceIn(0f, 1f) }
        if (eqBand != null && eqBand in 0..3 && eqDb != null) p.eq[eqBand] = eqDb.coerceIn(-12f, 12f)
    }

    /** Feed mono float samples (-1..1) to CH3..CH8 from a future USB/interface input adapter. */
    fun pushExternalInput(channelIndex: Int, samples: FloatArray, count: Int = samples.size) {
        if (channelIndex !in 2 until CHANNELS) return
        synchronized(externalLock) {
            val n = min(BLOCK, min(count, samples.size))
            System.arraycopy(samples, 0, external[channelIndex], 0, n)
            if (n < BLOCK) external[channelIndex].fill(0f, n, BLOCK)
        }
    }

    /** Decode common Android-supported audio files (MP3/AAC/M4A/OGG and WAV where extractor supports it). */
    fun loadAudio(resolver: ContentResolver, uri: Uri): Boolean {
        // Keep the explicit PCM WAV parser as a reliable fallback for uncompressed WAV.
        if (loadWav(resolver, uri)) return true
        return try {
            val extractor = MediaExtractor()
            extractor.setDataSource(resolver, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { track = i; format = f; break }
            }
            require(track >= 0 && format != null) { "Format audio tidak didukung Android" }
            val selectedFormat = format ?: error("Format audio tidak ditemukan")
            extractor.selectTrack(track)
            val mime = selectedFormat.getString(MediaFormat.KEY_MIME)!!
            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(selectedFormat, null, null, 0)
            decoder.start()
            val pcmBytes = ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var outChannels = selectedFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var outRate = selectedFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var outEncoding = AudioFormat.ENCODING_PCM_16BIT
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = decoder.dequeueInputBuffer(10000)
                    if (inIndex >= 0) {
                        val inBuffer = decoder.getInputBuffer(inIndex)!!
                        inBuffer.clear()
                        val size = extractor.readSampleData(inBuffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = decoder.dequeueOutputBuffer(info, 10000)
                when {
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = decoder.outputFormat
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) outChannels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) outRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) outEncoding = of.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                    outIndex >= 0 -> {
                        if (info.size > 0) {
                            val buffer = decoder.getOutputBuffer(outIndex)!!
                            buffer.position(info.offset); buffer.limit(info.offset + info.size)
                            val ch = outChannels.coerceIn(1, 2)
                            if (outEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                val samples = buffer.slice().order(ByteOrder.nativeOrder()).asFloatBuffer()
                                val frames = samples.remaining() / ch
                                repeat(frames) {
                                    var sum = 0f
                                    repeat(ch) { sum += samples.get().coerceIn(-1f, 1f) }
                                    val v = (sum / ch * 32767f).roundToInt().coerceIn(-32768, 32767)
                                    pcmBytes.write(v and 0xff); pcmBytes.write((v shr 8) and 0xff)
                                }
                            } else {
                                val samples = buffer.slice().order(ByteOrder.nativeOrder()).asShortBuffer()
                                val frames = samples.remaining() / ch
                                repeat(frames) {
                                    var sum = 0f
                                    repeat(ch) { sum += samples.get().toInt() / 32768f }
                                    val v = (sum / ch * 32767f).roundToInt().coerceIn(-32768, 32767)
                                    pcmBytes.write(v and 0xff); pcmBytes.write((v shr 8) and 0xff)
                                }
                            }
                        }
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        decoder.releaseOutputBuffer(outIndex, false)
                    }
                }
            }
            decoder.stop(); decoder.release(); extractor.release()
            val raw = pcmBytes.toByteArray()
            require(raw.isNotEmpty()) { "File audio kosong atau gagal didekode" }
            val shortBuffer = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val source = FloatArray(shortBuffer.remaining()) { shortBuffer.get().toFloat() / 32768f }
            music = if (outRate == SAMPLE_RATE) source else resample(source, outRate, SAMPLE_RATE)
            musicPosition = 0
            lastError = "Audio dimuat (${mime.substringAfter('/')})"
            true
        } catch (e: Exception) {
            lastError = e.message ?: "Gagal decode audio"
            false
        }
    }

    /** Loads uncompressed PCM WAV (16-bit mono/stereo). Other formats are rejected clearly. */
    fun loadWav(resolver: ContentResolver, uri: Uri): Boolean {
        return try {
            val input = resolver.openInputStream(uri) ?: error("Tidak bisa membuka file")
            val out = ByteArrayOutputStream()
            input.use { it.copyTo(out) }
            val bytes = out.toByteArray()
            require(bytes.size > 44 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") {
                "File bukan WAV PCM yang valid"
            }
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            var offset = 12; var format = 0; var channelsIn = 0; var rate = 0; var bits = 0
            var dataOffset = -1; var dataSize = 0
            while (offset + 8 <= bytes.size) {
                val id = String(bytes, offset, 4)
                val size = bb.getInt(offset + 4).coerceAtLeast(0)
                val start = offset + 8
                if (id == "fmt " && size >= 16 && start + 16 <= bytes.size) {
                    format = bb.getShort(start).toInt() and 0xffff
                    channelsIn = bb.getShort(start + 2).toInt() and 0xffff
                    rate = bb.getInt(start + 4)
                    bits = bb.getShort(start + 14).toInt() and 0xffff
                } else if (id == "data") {
                    dataOffset = start; dataSize = min(size, bytes.size - start); break
                }
                offset = start + size + (size and 1)
            }
            require(format == 1 && bits == 16 && channelsIn in 1..2 && rate > 0 && dataOffset >= 0) {
                "Format belum didukung. Gunakan WAV PCM 16-bit mono/stereo."
            }
            val frames = dataSize / (2 * channelsIn)
            val source = FloatArray(frames)
            var pos = dataOffset
            for (i in 0 until frames) {
                var sum = 0f
                repeat(channelsIn) { sum += bb.getShort(pos).toInt() / 32768f; pos += 2 }
                source[i] = sum / channelsIn
            }
            val converted = if (rate == SAMPLE_RATE) source else resample(source, rate, SAMPLE_RATE)
            music = converted
            musicPosition = 0
            lastError = "WAV dimuat: ${converted.size / SAMPLE_RATE}s"
            true
        } catch (e: Exception) {
            lastError = e.message ?: "Gagal memuat WAV"
            false
        }
    }

    private fun resample(src: FloatArray, from: Int, to: Int): FloatArray {
        val size = (src.size.toLong() * to / from).toInt().coerceAtLeast(1)
        return FloatArray(size) { i ->
            val x = i.toDouble() * from / to
            val a = x.toInt().coerceIn(0, src.lastIndex)
            val b = min(a + 1, src.lastIndex)
            val f = (x - a).toFloat()
            src[a] * (1f - f) + src[b] * f
        }
    }

    fun setMusicPlaying(playing: Boolean) { musicPlaying = playing && music != null }

    @Synchronized fun start(): Boolean {
        if (running) return true
        lastError = ""
        return try {
            val minIn = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val minOut = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            require(minIn > 0 && minOut > 0) { "Perangkat audio tidak mendukung 44.1 kHz" }
            val input = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minIn * 2, BLOCK * 4))
            val output = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(max(minOut * 2, BLOCK * 8))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            require(input.state == AudioRecord.STATE_INITIALIZED && output.state == AudioTrack.STATE_INITIALIZED) {
                "AudioRecord/AudioTrack gagal diinisialisasi"
            }
            recorder = input; player = output; running = true
            input.startRecording(); output.play()
            worker = Thread { audioLoop(input, output) }.apply { name = "Valensca-DSP"; priority = Thread.MAX_PRIORITY; start() }
            true
        } catch (e: Exception) {
            lastError = e.message ?: "Gagal memulai audio"
            stop(); false
        }
    }

    private fun audioLoop(input: AudioRecord, output: AudioTrack) {
        val mic = ShortArray(BLOCK)
        val out = ShortArray(BLOCK * 2)
        val filters = Array(CHANNELS) { Array(4) { Biquad() } }
        val lastEq = Array(CHANNELS) { FloatArray(4) { 999f } }
        val delay = FloatArray(SAMPLE_RATE / 2)
        val reverbA = FloatArray(1559); val reverbB = FloatArray(1877); var dPos = 0; var rA = 0; var rB = 0
        val channelSamples = Array(CHANNELS) { FloatArray(BLOCK) }
        while (running) {
            val read = input.read(mic, 0, BLOCK, AudioRecord.READ_BLOCKING)
            if (read <= 0) continue
            for (c in 0 until CHANNELS) channelSamples[c].fill(0f)
            for (i in 0 until read) channelSamples[0][i] = mic[i] / 32768f
            synchronized(externalLock) { for (c in 2 until CHANNELS) System.arraycopy(external[c], 0, channelSamples[c], 0, BLOCK) }
            val musicData = music
            if (musicPlaying && musicData != null) {
                var mp = musicPosition
                for (i in 0 until read) {
                    if (mp >= musicData.size) { musicPlaying = false; break }
                    channelSamples[1][i] = musicData[mp++]
                }
                musicPosition = mp
            }
            val p = params
            var auxDelay = 0f; var auxVerb = 0f
            for (i in 0 until read) {
                var left = 0f; var right = 0f
                for (c in 0 until CHANNELS) {
                    val cp = p[c]
                    if (cp.muted) continue
                    val eq = cp.eq
                    for (b in 0..3) if (abs(eq[b] - lastEq[c][b]) > 0.05f) {
                        filters[c][b].setPeaking(SAMPLE_RATE.toFloat(), floatArrayOf(100f, 400f, 2500f, 8000f)[b], 0.85f, eq[b])
                        lastEq[c][b] = eq[b]
                    }
                    var s = channelSamples[c][i] * cp.gain
                    for (b in 0..3) s = filters[c][b].process(s)
                    s *= cp.fader
                    val pan = cp.pan
                    val lg = if (pan > 0f) 1f - pan else 1f
                    val rg = if (pan < 0f) 1f + pan else 1f
                    left += s * lg; right += s * rg
                    auxDelay += s * cp.aux1
                    auxVerb += s * cp.aux2
                }
                val delayed = delay[dPos]
                delay[dPos] = (auxDelay + delayed * 0.28f).coerceIn(-1.5f, 1.5f)
                dPos = (dPos + 1) % delay.size
                val va = reverbA[rA]; val vb = reverbB[rB]
                reverbA[rA] = (auxVerb + va * 0.72f + vb * 0.08f).coerceIn(-1.5f, 1.5f)
                reverbB[rB] = (auxVerb + vb * 0.69f - va * 0.06f).coerceIn(-1.5f, 1.5f)
                rA = (rA + 1) % reverbA.size; rB = (rB + 1) % reverbB.size
                val fx = delayed * delayLevel + (va + vb) * 0.5f * reverbLevel
                val master = masterLevel
                out[i * 2] = ((left + fx) * master * 26000f).roundToInt().coerceIn(-32768, 32767).toShort()
                out[i * 2 + 1] = ((right + fx) * master * 26000f).roundToInt().coerceIn(-32768, 32767).toShort()
            }
            val count = read * 2
            var written = 0
            while (written < count && running) {
                val n = output.write(out, written, count - written, AudioTrack.WRITE_BLOCKING)
                if (n <= 0) break
                written += n
            }
        }
    }

    @Synchronized fun stop() {
        running = false
        try { worker?.join(700) } catch (_: InterruptedException) {}
        worker = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        try { player?.pause() } catch (_: Exception) {}
        try { player?.flush() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        recorder = null; player = null
    }

    private class Biquad {
        private var b0 = 1f; private var b1 = 0f; private var b2 = 0f
        private var a1 = 0f; private var a2 = 0f
        private var x1 = 0f; private var x2 = 0f; private var y1 = 0f; private var y2 = 0f
        fun setPeaking(sr: Float, freq: Float, q: Float, gainDb: Float) {
            val a = 10.0.pow(gainDb / 40.0).toFloat()
            val w = (2.0 * Math.PI * freq / sr).toFloat()
            val alpha = sin(w) / (2f * q)
            val c = cos(w); val a0 = 1f + alpha / a
            b0 = (1f + alpha * a) / a0; b1 = (-2f * c) / a0; b2 = (1f - alpha * a) / a0
            a1 = (-2f * c) / a0; a2 = (1f - alpha / a) / a0
        }
        fun process(x: Float): Float {
            val y = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2
            x2=x1; x1=x; y2=y1; y1=y
            return if (y.isFinite()) y else 0f
        }
    }
}
