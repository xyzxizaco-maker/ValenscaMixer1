package id.valensca.mixer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var engine: AudioEngine
    private lateinit var status: TextView
    private lateinit var musicInfo: TextView
    private val channelNames = arrayOf("MIC 1", "MUSIC", "LINE 3", "LINE 4", "LINE 5", "LINE 6", "LINE 7", "LINE 8")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.statusBarColor = Color.rgb(12, 18, 25)
        window.navigationBarColor = Color.BLACK
        engine = AudioEngine()
        buildMixer()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildMixer() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(14, 21, 29))
            setPadding(dp(10), dp(7), dp(10), dp(6))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "VALENSCA  /  DIGITAL LIVE MIXER"
            textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        status = TextView(this).apply { text = "STOPPED"; textSize = 11f; setTextColor(Color.rgb(255, 190, 70)) }
        header.addView(status)
        page.addView(header)

        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        toolbar.addView(actionButton("START AUDIO") { startAudio() })
        toolbar.addView(actionButton("STOP") { engine.stop(); status.text = "STOPPED" })
        toolbar.addView(actionButton("LOAD WAV") { pickWav() })
        toolbar.addView(actionButton("PLAY MUSIC") { engine.setMusicPlaying(true); musicInfo.text = "MUSIC: PLAYING" })
        toolbar.addView(actionButton("STOP MUSIC") { engine.setMusicPlaying(false); musicInfo.text = "MUSIC: STOPPED" })
        musicInfo = TextView(this).apply { text = "MUSIC: no file"; textSize = 10f; setTextColor(Color.LTGRAY); setPadding(dp(8), 0, 0, 0) }
        toolbar.addView(musicInfo, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(toolbar)

        val horizontal = HorizontalScrollView(this).apply { isFillViewport = true; horizontalScrollBarEnabled = true }
        val strips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 8) {
            strips.addView(makeChannel(i), LinearLayout.LayoutParams(dp(158), -1).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        strips.addView(makeMaster(), LinearLayout.LayoutParams(dp(180), -1).apply {
            setMargins(dp(5), dp(3), dp(3), dp(3))
        })
        horizontal.addView(strips)
        page.addView(horizontal, LinearLayout.LayoutParams(-1, 0, 1f))

        page.addView(TextView(this).apply {
            text = "CH1 = microphone • CH2 = PCM WAV music • CH3–CH8 = virtual input slots • Output = Android stereo"
            textSize = 9f; setTextColor(Color.GRAY); setPadding(dp(3), dp(4), 0, 0)
        })
        setContentView(page)
    }

    private fun makeChannel(index: Int): android.view.View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(5), dp(6), dp(5)); background = panel()
        }
        box.addView(label("CH %02d".format(index + 1), 14f, true))
        box.addView(label(channelNames[index], 10f, true))
        box.addView(label(if (index == 0) "PHONE MIC" else if (index == 1) "WAV PLAYER" else "VIRTUAL INPUT", 8f, false))
        box.addView(label("GAIN", 9f, true))
        box.addView(slider(0, 200, 80) { engine.setChannel(index, gain = it / 100f) })
        box.addView(label("4-BAND PARAMETRIC EQ  (-12 / +12 dB)", 8f, true))
        val bands = arrayOf("LOW 100 Hz", "LOW MID 400 Hz", "HIGH MID 2.5 kHz", "HIGH 8 kHz")
        for (b in 0..3) {
            box.addView(label(bands[b], 8f, false))
            box.addView(slider(0, 240, 120) { engine.setChannel(index, eqBand = b, eqDb = (it - 120) / 10f) })
        }
        box.addView(label("PAN  L  /  R", 9f, true))
        box.addView(slider(0, 200, 100) { engine.setChannel(index, pan = (it - 100) / 100f) })
        box.addView(label("FADER", 9f, true))
        box.addView(slider(0, 100, 80) { engine.setChannel(index, fader = it / 100f) })
        box.addView(label("AUX 1  /  DELAY", 8f, false))
        box.addView(slider(0, 100, 0) { engine.setChannel(index, aux1 = it / 100f) })
        box.addView(label("AUX 2  /  REVERB", 8f, false))
        box.addView(slider(0, 100, 0) { engine.setChannel(index, aux2 = it / 100f) })
        val mute = ToggleButton(this).apply {
            textOn = "MUTED"; textOff = "MUTE"; textSize = 10f
            setOnCheckedChangeListener { _, checked -> engine.setChannel(index, muted = checked) }
        }
        box.addView(mute, LinearLayout.LayoutParams(-1, dp(34)))
        return ScrollView(this).apply { isFillViewport = true; addView(box) }
    }

    private fun makeMaster(): android.view.View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8)); background = panel()
        }
        box.addView(label("MASTER", 16f, true))
        box.addView(label("STEREO L / R", 10f, false))
        box.addView(label("MASTER LEVEL", 9f, true))
        box.addView(slider(0, 100, 85) { engine.masterLevel = it / 100f })
        box.addView(label("AUX 1 RETURN • DELAY", 9f, true))
        box.addView(slider(0, 100, 25) { engine.delayLevel = it / 100f })
        box.addView(label("AUX 2 RETURN • REVERB", 9f, true))
        box.addView(slider(0, 100, 25) { engine.reverbLevel = it / 100f })
        box.addView(label("OUTPUT ROUTING", 10f, true))
        box.addView(label("Android stereo playback\nUse compatible streaming app or external audio interface for YouTube", 9f, false))
        return ScrollView(this).apply { isFillViewport = true; addView(box) }
    }

    private fun pickWav() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        try { startActivityForResult(intent, 20) } catch (_: Exception) {
            Toast.makeText(this, "File picker tidak tersedia", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated by Android, retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val ok = engine.loadAudio(contentResolver, uri)
            musicInfo.text = if (ok) "MUSIC: ${engine.lastError}" else "WAV ERROR: ${engine.lastError}"
            Toast.makeText(this, engine.lastError, Toast.LENGTH_LONG).show()
        }
    }

    private fun startAudio() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return
        }
        val ok = engine.start()
        status.text = if (ok) "AUDIO RUNNING" else "AUDIO ERROR: ${engine.lastError}"
        status.setTextColor(if (ok) Color.rgb(80, 220, 140) else Color.RED)
        if (!ok) Toast.makeText(this, engine.lastError, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() { engine.stop(); super.onDestroy() }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 9f; minWidth = 0; setPadding(dp(5), 0, dp(5), 0); setOnClickListener { action() }
    }
    private fun slider(min: Int, max: Int, value: Int, changed: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = value
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { changed(progress) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        layoutParams = LinearLayout.LayoutParams(-1, dp(27))
    }
    private fun label(text: String, size: Float, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; gravity = Gravity.CENTER
        setTextColor(Color.WHITE); if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(2), 0, dp(2))
    }
    private fun panel() = GradientDrawable().apply {
        setColor(Color.rgb(31, 43, 56)); cornerRadius = dp(7).toFloat()
        setStroke(dp(1), Color.rgb(66, 83, 99))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
