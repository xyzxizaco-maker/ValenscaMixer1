# Valensca Mixer Android — Prototype 0.2

Original Android mixer prototype inspired by the workflow of a digital live console. It is not a port of Cockos REAPER.

## Included in this update
- 8 software channel strips with independent gain, fader, pan and mute.
- Four fixed-frequency parametric peaking EQ bands per strip: 100 Hz, 400 Hz, 2.5 kHz and 8 kHz, +/-12 dB.
- AUX 1 feeds a delay effect; AUX 2 feeds a simple algorithmic reverb.
- Stereo master output through Android AudioTrack at 44.1 kHz.
- CH1 captures the phone microphone through AudioRecord.
- CH2 loads local audio files using Android's document picker. PCM 16-bit WAV is directly supported; MP3/AAC/M4A/OGG depend on Android MediaCodec support.
- CH3–CH8 are software input slots exposed by `pushExternalInput()`. They are not yet connected to a physical multichannel USB audio interface.

## Build
1. Install Android Studio (recent stable version) and JDK 17.
2. Open this folder as an existing project.
3. Allow Gradle sync to finish (internet is needed to download Android Gradle Plugin/Kotlin plugin).
4. Connect an Android device, enable USB debugging, then Run `app`.
5. Grant microphone permission. Tap LOAD WAV, choose an audio file, tap START AUDIO, then PLAY MUSIC.

## Important limitations
- This is a functional development prototype, not a production-ready low-latency mixer. AudioRecord/AudioTrack are used for broad Android compatibility; a production build should move the real-time DSP path to Oboe/AAudio in C++ and add underrun/latency diagnostics.
- CH3–CH8 currently accept samples only through the engine API. True simultaneous 8-input hardware requires a compatible USB audio interface and a USB Audio adapter/driver layer. A phone's built-in microphone is only one input.
- AUX 1 uses a simple feedback delay; AUX 2 uses a lightweight two-line reverb approximation. These are starter effects, not studio-grade plugins.
- EQ bands are fixed-frequency peaking filters.
- Stereo output is sent to Android playback. It does not automatically become YouTube Live's microphone/input. For streaming, use a streaming app that explicitly supports internal audio capture, or route the stereo output through a compatible USB audio interface/mixer into the phone.
- Use headphones while testing microphone monitoring to prevent acoustic feedback. Start with low levels.

## Project settings
- Package: `id.valensca.mixer`
- Minimum Android: API 26
- Target SDK: 35
- Version: 0.2.0 (update version fields in `app/build.gradle.kts` before release)
