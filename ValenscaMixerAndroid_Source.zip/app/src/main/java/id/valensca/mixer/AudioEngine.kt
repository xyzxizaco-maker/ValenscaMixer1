package id.valensca.mixer

/**
 * Audio engine scaffold for the Valensca Mixer project.
 * The current build establishes the Android project and mixer interface.
 * Real-time PCM decoding, per-channel DSP, AUX buses and FX routing are
 * intentionally left for the next implementation stage.
 */
class AudioEngine {
    data class ChannelState(
        var gain: Float = 1f,
        var fader: Float = 0.8f,
        var low: Float = 0f,
        var lowMid: Float = 0f,
        var highMid: Float = 0f,
        var high: Float = 0f,
        var aux1: Float = 0f,
        var aux2: Float = 0f,
        var muted: Boolean = false
    )

    val channels: Array<ChannelState> = Array(8) { ChannelState() }
    var masterLeft: Float = 0.8f
    var masterRight: Float = 0.8f
}
