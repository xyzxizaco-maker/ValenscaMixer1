package id.valensca.mixer

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Intent

class MainActivity : Activity() {
    private val bg = Color.rgb(17, 21, 29)
    private val panel = Color.rgb(29, 36, 47)
    private val accent = Color.rgb(35, 190, 160)
    private val channelNames = Array(8) { "CH ${it + 1}" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildMixer()
    }

    private fun buildMixer() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(12, 10, 12, 10)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "VALENSCA  MIXER"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val fileButton = Button(this).apply {
            text = "INPUT FILE"
            setOnClickListener { openAudioFile() }
        }
        header.addView(fileButton)
        root.addView(header)

        val status = TextView(this).apply {
            text = "8 CHANNEL  •  LIVE MIXER"
            textSize = 11f
            setTextColor(accent)
            setPadding(2, 4, 2, 8)
        }
        root.addView(status)

        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            fillViewport = false
        }
        val channels = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        for (i in 0 until 8) {
            val strip = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setBackgroundColor(panel)
                setPadding(9, 10, 9, 10)
            }
            val name = TextView(this).apply {
                text = channelNames[i]
                textSize = 16f
                setTextColor(Color.WHITE)
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }
            strip.addView(name)
            addLabel(strip, "GAIN")
            addSlider(strip, 0, 100, 50, "gain_$i")
            addLabel(strip, "EQ 4-BAND")
            listOf("LOW", "LOW MID", "HI MID", "HIGH").forEach {
                addSlider(strip, 0, 100, 50, "${it}_$i", compact = true)
            }
            addLabel(strip, "AUX 1 / 2")
            addSlider(strip, 0, 100, 0, "aux1_$i", compact = true)
            addSlider(strip, 0, 100, 0, "aux2_$i", compact = true)
            addLabel(strip, "FADER")
            addSlider(strip, 0, 100, 80, "fader_$i")
            val mute = CheckBox(this).apply {
                text = "MUTE"
                setTextColor(Color.WHITE)
            }
            strip.addView(mute)
            channels.addView(strip, LinearLayout.LayoutParams(dp(150), -1).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        scroll.addView(channels)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 8, 4, 0)
        }
        val fx = TextView(this).apply {
            text = "FX  Reverb  [OFF]     Delay  [OFF]"
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }
        footer.addView(fx, LinearLayout.LayoutParams(0, -2, 1f))
        val master = TextView(this).apply {
            text = "MASTER L/R"
            textSize = 14f
            setTextColor(accent)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        footer.addView(master)
        val masterSlider = SeekBar(this).apply { max = 100; progress = 80 }
        root.addView(footer)
        root.addView(masterSlider)
        setContentView(root)
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 10f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
    }

    private fun addSlider(parent: LinearLayout, min: Int, max: Int, value: Int, tagName: String, compact: Boolean = false) {
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            tag = tagName
        }
        parent.addView(seek, LinearLayout.LayoutParams(-1, if (compact) dp(28) else dp(42)))
    }

    private fun openAudioFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK && data?.data != null) {
            Toast.makeText(this, "File dipilih. Integrasi audio playback/mixing menyusul pada tahap berikutnya.", Toast.LENGTH_LONG).show()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
